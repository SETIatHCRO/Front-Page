Readme file for R7608A SSW firmware.

Copyright (C) HighPoint Technologies, Inc. All rights reserved.
Last updated on Feb 19, 2025.

Please review this file for important information about compatibility issues and
differences in operation that were discovered after our product manuals were
created. In case of conflict among various parts of the documentation set, this
file contains the most current information.

Note: The latest firmware and product documentation will be available for
download at http://www.highpoint-tech.com

This file is divided into the following major sections:

1. Software version
2. Files listing
3. Supported product
4. Revision history


1. Software version
====================
    Firmware version: v5.15.11.0

2. Files listing
=================
    README.txt                                          This file
    R7608ASSW_HLK_vx.xx.x.x_20x_xx_xx.blf          Firmware for R7608A

3. Supported product
====================================== 
    R7608A

4. Revision history
====================
    v5.15.11.0 02/19/2025
       * First release of R7608A.
